garak.buffs.low_resource_languages
==================================

.. automodule:: garak.buffs.low_resource_languages
   :members:
   :undoc-members:
   :show-inheritance:
