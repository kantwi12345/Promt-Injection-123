garak.buffs.lowercase
=====================

.. automodule:: garak.buffs.lowercase
   :members:
   :undoc-members:
   :show-inheritance:
