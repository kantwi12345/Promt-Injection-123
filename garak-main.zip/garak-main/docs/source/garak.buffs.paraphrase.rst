garak.buffs.paraphrase
======================

.. automodule:: garak.buffs.paraphrase
   :members:
   :undoc-members:
   :show-inheritance:
