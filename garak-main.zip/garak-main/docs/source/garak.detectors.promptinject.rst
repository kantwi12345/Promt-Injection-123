garak.detectors.promptinject
============================

.. automodule:: garak.detectors.promptinject
   :members:
   :undoc-members:
   :show-inheritance:
