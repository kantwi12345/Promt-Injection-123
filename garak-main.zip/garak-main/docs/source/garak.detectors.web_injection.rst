garak.detectors.web_injection
=============================

.. automodule:: garak.detectors.web_injection
   :members:
   :undoc-members:
   :show-inheritance:
