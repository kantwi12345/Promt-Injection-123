garak.generators.cohere
=======================

.. automodule:: garak.generators.cohere
   :members:
   :undoc-members:
   :show-inheritance:
